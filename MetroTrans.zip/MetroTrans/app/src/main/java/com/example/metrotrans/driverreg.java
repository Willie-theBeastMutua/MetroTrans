package com.example.metrotrans;

public class driverreg {
    public String fname;
    public String lname;
    public String Email;
    public String mobile;
    public String roles;
    public driverreg(){

    }

    public driverreg(String fname, String lname, String email, String mobile, String roles) {
        this.fname = fname;
        this.lname = lname;
        Email = email;
        this.mobile = mobile;
        this.roles = roles;
    }
}
