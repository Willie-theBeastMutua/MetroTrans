package com.example.metrotrans;


public interface OnSeatSelected {

    void onSeatSelected(int count);
}
